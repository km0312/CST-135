package com.example.activity7;

public class Photo {
}

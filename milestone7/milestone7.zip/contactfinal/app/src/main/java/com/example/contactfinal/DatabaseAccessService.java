package com.example.contactfinal;

import java.util.ArrayList;


public class DatabaseAccessService implements DataAccessService {

    private String targetDB;

    /**

     * No-arg constructor for class

     */

    public DatabaseAccessService() {

        this(null);

    }

    /**

     * non-default constructor for the class that accepts targetDB URI as argument

     * @param targetDB the target database

     */

    public DatabaseAccessService(String targetDB) {

        this.setTargetDB(targetDB);

    }

    /**

     * Get the target database

     * @return the target database

     */

    public String getTargetDB() {

        return targetDB;

    }

    /**

     * Set the target database

     * @param targetDB the target database

     */

    public void setTargetDB(String targetDB) {

        this.targetDB = targetDB;

    }



    // returns null until DataAccessService is fully implemented

    @Override

    public ArrayList<Contact> readAllContacts() {

        return null;

        // TODO Auto-generated method stub



    }



    @Override

    public String toString() {

        return "DatabaseAccessService [targetDB=" + targetDB + "]";

    }

    @Override

    public void saveAllContacts(ArrayList<Contact> list) {

        // TODO Auto-generated method stub



    }



}
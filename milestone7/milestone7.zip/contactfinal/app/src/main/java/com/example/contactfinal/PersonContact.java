package com.example.contactfinal;

import java.util.ArrayList;

import java.util.Date;





public class PersonContact extends Contact {

    private Date dateOfBirth;

    private String description;

    private ArrayList<Contact> listOfRelatives = new ArrayList<>();



    /**

     * No-arg constructor for PersonContact

     */

    public PersonContact() {

        this(null, 0L, null, 0, 0, 0, "New Person Contact");



    }



    /**

     * Full Argument constructor for PersonContact

     *

     * @param birthYear   the birthYear of the Contact

     * @param birthMonth  the birthMonth of the Contact

     * @param birthDay    the birthDay of the Contact

     * @param description the description of the Person Contact

     */

    public PersonContact(String name, Long phone, String hobby, int birthYear, int birthMonth, int birthDay, String description) {

        super(name, phone, new Location(), new Photo(), hobby);

        this.setDateOfBirth(birthYear, birthMonth, birthDay);

        this.description = description;

    }



    /**

     * Date of birth of the Person Contact

     *

     * @return the birth date of the Person Contact

     */

    public java.util.Date getDateOfBirth() {

        return dateOfBirth;

    }



    /**

     * Set the birth date of the Person Contact

     *

     * @param year  The Person Contact Year of birth

     * @param month the Person Contact Month of birth

     * @param day   the Person Contact Day of birth

     */

    public void setDateOfBirth(int year, int month, int day) {

        this.dateOfBirth = new Date(year, month, day);

    }



    /**

     * Get description of Person Contact

     *

     * @return the description of the Person Contact

     */

    public String getDescription() {

        return description;

    }



    /**

     * Set the description for the Person Contact

     *

     * @param description The description of the person contact

     */

    public void setDescription(String description) {

        this.description = description;

    }



    /**

     * Get list of relatives (other contacts) for the Person Contact

     *

     * @return a list of relatives

     */

    public ArrayList<Contact> getListOfRelatives() {

        return listOfRelatives;

    }



    /**

     * Add a relative for Person Contact

     *

     * @param relative a relative of person contact

     */

    public void addRelative(Contact relative) {

        this.listOfRelatives.add(relative);

    }



    /**

     * Remove a relative for person Contact

     *

     * @param relative a relative of person contact

     */

    public void removeRelative(Contact relative) {

        this.listOfRelatives.remove(relative);

    }



    @Override

    public String toString() {

        return super.toString() + "as PersonContact [dateOfBirth=" + dateOfBirth + ", description=" + description + ", listOfRelatives="

                + listOfRelatives + "]";

    }



}
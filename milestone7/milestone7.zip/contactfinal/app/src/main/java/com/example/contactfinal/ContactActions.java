package com.example.contactfinal;

import android.Manifest;

import android.content.Intent;

import android.content.pm.PackageManager;

import android.net.Uri;

import android.support.v4.app.ActivityCompat;

import android.support.v4.content.ContextCompat;

import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;

import android.widget.Button;

import android.widget.TextView;

import android.widget.Toast;



public class ContactActions extends AppCompatActivity {

    TextView tv_ca_name, tv_ca_phone, tv_ca_email, tv_ca_location;

    Button btn_call, btn_text, btn_email, btn_map;

    final static int PERMISSION_TO_CALL = 1;

    String location;

    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_contact_actions);



        tv_ca_name = findViewById(R.id.tv_ca_name);

        tv_ca_phone = findViewById(R.id.tv_ca_phone);

        tv_ca_email = findViewById(R.id.tv_ca_email);

        tv_ca_location = findViewById(R.id.tv_ca_location);



        btn_call = findViewById(R.id.btn_call);

        btn_text = findViewById(R.id.btn_text);

        btn_email = findViewById(R.id.btn_email);

        btn_map = findViewById(R.id.btn_map);



        Bundle incomingIntent = getIntent().getExtras();

        // capture all incoming intent extras as variables

        if (incomingIntent != null) {

            String newName = incomingIntent.getString("name");

            String newPhone = incomingIntent.getString("phone");

            String newEmail = incomingIntent.getString("email");

            String location = incomingIntent.getString("street") + ", " + incomingIntent.getString("city") + ", " + incomingIntent.getString("state");



            // fill in form

            tv_ca_name.setText(newName);

            tv_ca_phone.setText(newPhone);

            tv_ca_email.setText(newEmail);

            tv_ca_location.setText(location);

        }



        btn_call.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {

                callPhoneNumber(tv_ca_phone.getText().toString());

            }

        });

        btn_text.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {

                composeMmsMessage(tv_ca_phone.getText().toString(), "Hello world!");

            }

        });

        btn_email.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {

                String[] emails = new String[1];

                emails[0] = tv_ca_email.getText().toString();

                composeEmail(emails, "Hello world!");

            }

        });

        btn_map.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {

                Uri mapUri = Uri.parse("geo:0,0?q=" + tv_ca_location.getText().toString());

                showMap(mapUri);

            }

        });

    }

    public void composeEmail(String[] addresses, String subject) {

        Intent intent = new Intent(Intent.ACTION_SENDTO);

        intent.setData(Uri.parse("mailto:")); // only email apps should handle this

        intent.putExtra(Intent.EXTRA_EMAIL, addresses);

        intent.putExtra(Intent.EXTRA_SUBJECT, subject);

        if (intent.resolveActivity(getPackageManager()) != null) {

            startActivity(intent);

        }

    }

    public void callPhoneNumber(String phoneNumber) {

        Intent intent = new Intent(Intent.ACTION_CALL);

        intent.setData(Uri.parse("tel:" + phoneNumber));



        if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CALL_PHONE)

                != PackageManager.PERMISSION_GRANTED) {

            // Permission is not granted

            // No explanation needed; request the permission

            ActivityCompat.requestPermissions(ContactActions.this,

                    new String[]{Manifest.permission.CALL_PHONE},

                    PERMISSION_TO_CALL);



        } else {

            if (intent.resolveActivity(getPackageManager()) != null) {

                startActivity(intent);

            }

        }







    }

    public void composeMmsMessage(String phoneNumber, String message) {

        Intent intent = new Intent(Intent.ACTION_SENDTO);

        intent.setData(Uri.parse("smsto:" + phoneNumber));  // This ensures only SMS apps respond

        intent.putExtra("sms_body", message);

        if (intent.resolveActivity(getPackageManager()) != null) {

            startActivity(intent);

        }

    }

    public void showMap(Uri geoLocation) {

        Intent intent = new Intent(Intent.ACTION_VIEW);

        intent.setData(geoLocation);

        if (intent.resolveActivity(getPackageManager()) != null) {

            startActivity(intent);

        }

    }

    @Override

    public void onRequestPermissionsResult(int requestCode,

                                           String[] permissions, int[] grantResults) {

        switch (requestCode) {

            case PERMISSION_TO_CALL: {

                // If request is cancelled, the result arrays are empty.

                if (grantResults.length > 0

                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    callPhoneNumber(tv_ca_phone.getText().toString());

                } else {

                    Toast.makeText(this, "Cannot make a call without your permission.", Toast.LENGTH_SHORT).show();

                }

                return;

            }



            // other 'case' lines to check for other

            // permissions this app might request.

        }

    }

}
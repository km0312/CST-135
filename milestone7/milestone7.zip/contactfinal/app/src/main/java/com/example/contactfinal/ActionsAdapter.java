package com.example.contactfinal;

import android.app.Activity;

import android.content.Context;

import android.view.LayoutInflater;

import android.view.View;

import android.view.ViewGroup;

import android.widget.BaseAdapter;

import android.widget.TextView;



public class ActionsAdapter extends BaseAdapter {



    Activity mActivity;

    AddressBook addressBook;



    public ActionsAdapter(Activity mActivity, AddressBook addressBook) {

        this.mActivity = mActivity;

        this.addressBook = addressBook;

    }



    @Override

    public int getCount() {

        return addressBook.getContactList().size();

    }



    @Override

    public Contact getItem(int position) {

        return addressBook.getContactList().get(position);

    }



    @Override

    public long getItemId(int position) {

        return 0;

    }



    @Override

    public View getView(int position, View convertView, ViewGroup parent) {

        View actionOneLine;



        LayoutInflater inflater = (LayoutInflater) mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        actionOneLine = inflater.inflate(R.layout.actions_one_line, parent, false);



        TextView tv_name = actionOneLine.findViewById(R.id.tv_actions_name);

        TextView tv_id = actionOneLine.findViewById(R.id.tv_actions_id);

        TextView tv_phone = actionOneLine.findViewById(R.id.tv_actions_phone_value);

        TextView tv_email = actionOneLine.findViewById(R.id.tv_actions_email_value);



        Contact c = this.getItem(position);



        tv_name.setText(c.getName());

        tv_id.setText(Integer.toString(c.getid()));

        tv_phone.setText(Long.toString(c.getPhone()));

        tv_email.setText(c.getEmail());



        return actionOneLine;

    }

}
package com.example.contactfinal;

import java.util.ArrayList;



public interface DataAccessService {

    /**

     * Read all contacts from a specified data source

     * @return the contacts constructed from parameters derived from the data source

     */

    public ArrayList<Contact> readAllContacts();

    /**

     * Save all contacts as comma-delimited values in a specified data target.

     * @param list The list from which the data saved to target is derived.

     */

    public void saveAllContacts(ArrayList<Contact> list);

}
package com.example.contactfinal;

import android.content.Intent;

import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;

import android.widget.Button;

import android.widget.EditText;

import android.widget.Toast;



import java.util.Random;



public class AddPersonContact extends AppCompatActivity {

    Button btn_contact_ok;

    EditText et_name, et_phone, et_email, et_description, et_street, et_city, et_state;



    int positionToEdit = -1;



    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_person_contact);

        btn_contact_ok = findViewById(R.id.btn_contact_ok);



        et_name = findViewById(R.id.et_name_field);

        et_phone = findViewById(R.id.et_phone_field);

        et_email = findViewById(R.id.et_email_field);

        et_description = findViewById(R.id.et_description_field);

        et_street = findViewById(R.id.et_street_field);

        et_city = findViewById(R.id.et_city_field);

        et_state = findViewById(R.id.et_state_field);









        // EDIT FORM FUNCTIONALITY STARTS HERE



        Bundle incomingIntent = getIntent().getExtras();

        // capture all incoming intent extras as variables

        if (incomingIntent != null) {

            String newName = incomingIntent.getString("name");

            String newPhone = incomingIntent.getString("phone");

            String newEmail = incomingIntent.getString("email");

            String newDescription = incomingIntent.getString("description");

            String newStreet = incomingIntent.getString("street");

            String newCity = incomingIntent.getString("city");

            String newState = incomingIntent.getString("state");

            positionToEdit = incomingIntent.getInt("edit");



            // fill in form

            et_name.setText(newName);

            et_phone.setText(newPhone);

            et_email.setText(newEmail);

            et_description.setText(newDescription);

            et_street.setText(newStreet);

            et_city.setText(newCity);

            et_state.setText(newState);

        }









        btn_contact_ok.setOnClickListener(v -> {

            // get the string from et_view objects

            String newName = et_name.getText().toString();

            String newPhone = et_phone.getText().toString();

            String newEmail = et_email.getText().toString();

            String newDescription = et_description.getText().toString();

            String newStreet = et_street.getText().toString();

            String newCity = et_city.getText().toString();

            String newState = et_state.getText().toString();



            //Start MainActivity again



            Intent i = new Intent(v.getContext(), MainActivity.class);



            // put strings into message for the MainActivity

            i.putExtra("edit", positionToEdit);

            i.putExtra("name", newName);

            i.putExtra("phone", newPhone);

            i.putExtra("email", newEmail);

            i.putExtra("description", newDescription);

            i.putExtra("street", newStreet);

            i.putExtra("city", newCity);

            i.putExtra("state", newState);

            i.putExtra("type", "p");



            startActivity(i);

            finish();

            return;

        });

    }

}
package com.example.contactfinal;

import android.content.Intent;

import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;

import android.widget.Button;

import android.widget.ListView;



public class ShowAllContacts extends AppCompatActivity {

    Button btn_add, btn_business_sort, btn_person_sort;

    ListView lv_contactlist;

    ContactAdapter adapter;

    AddressBook contactList;





    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_show_all_contacts);



        btn_add = findViewById(R.id.btn_add);

        btn_business_sort = findViewById(R.id.btn_business_sort);

        btn_person_sort = findViewById(R.id.btn_person_sort);

        lv_contactlist = findViewById(R.id.lv_contactlist);

        contactList = ((MyApplication) this.getApplication()).getAddressBook();

        adapter = new ContactAdapter(ShowAllContacts.this, contactList);

        lv_contactlist.setAdapter(adapter);

        adapter.notifyDataSetChanged();



        lv_contactlist.setOnItemClickListener((parent, view, position, id) -> ShowAllContacts.this.editPerson(position));}



    public void editPerson(int position) {

        Intent i = new Intent(getApplicationContext(), AddPersonContact.class);



        // get the contents of contacts at position

        Contact c = contactList.getContactList().get(position);



        i.putExtra("name", c.getName());

        i.putExtra("phone", Long.toString(c.getPhone()));

        i.putExtra("email", c.getEmail());

        i.putExtra("description", ((PersonContact) c).getDescription());

        i.putExtra("street", c.getLocation().getStreet());

        i.putExtra("city", c.getLocation().getCity());

        i.putExtra("state", c.getLocation().getState());

        i.putExtra("edit", position);



        startActivity(i);

    }

}
package com.example.contactfinal;

import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;



public class ShowContactByID extends AppCompatActivity {



    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_show_contact_by_id);

    }

}
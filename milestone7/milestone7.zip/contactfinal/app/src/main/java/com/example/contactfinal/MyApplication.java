package com.example.contactfinal;

import android.app.Application;

import android.os.Environment;

import android.util.Log;



import java.io.File;







public class MyApplication extends Application {



    private String path = Environment.getExternalStorageDirectory().toURI().toString();

    private File file = new File(Environment.getExternalStorageDirectory().toString(), "temp.txt");

    private FileAccessService fileAccess = new FileAccessService(file);

    private AddressBook addressBook = new AddressBook(fileAccess.readAllContacts());



    public void setAddressBook(AddressBook addressBook) {

        this.addressBook = addressBook;

    }

    public AddressBook getAddressBook() {

        return this.addressBook;

    }



    public FileAccessService getFile() {

        return fileAccess;

    }



    public void setFile(FileAccessService file) {

        this.fileAccess = file;

    }



    public File getFileObject() {

        return this.file;

    }



}
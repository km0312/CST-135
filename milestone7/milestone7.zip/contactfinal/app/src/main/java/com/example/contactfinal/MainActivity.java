package com.example.contactfinal;

import android.content.Context;

import android.content.Intent;

import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;

import android.util.Log;

import android.view.View;

import android.widget.Button;

import android.widget.Toast;



import java.io.File;



public class MainActivity extends AppCompatActivity {

    AddressBook addressBook;



    Button b_main1, b_main2, b_main3, b_main6;



    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);



        b_main1 = (Button) findViewById(R.id.b_main1);

        b_main2 = (Button) findViewById(R.id.b_main2);

        b_main3 = (Button) findViewById(R.id.b_main3);

        b_main6 = (Button) findViewById(R.id.b_main6);

        addressBook = ((MyApplication) getApplication()).getAddressBook();



        // Verify visually that the storage file has been created

        Log.d("JackActivityLog", "This is the Main Activity");

        Boolean fileAccess = ((MyApplication) getApplication()).getFile().getTargetFile().isFile();

        Toast.makeText(this,Boolean.toString(((MyApplication) getApplication()).getFile().getTargetFile().isFile()), Toast.LENGTH_LONG).show();



        // listen for incoming intent extras

        Bundle incomingExtras = getIntent().getExtras();

        //capture incoming data

        if (incomingExtras != null && incomingExtras.getString("name") != null) {

            String name = incomingExtras.getString("name");

            Long phone;

            String email = incomingExtras.getString("email");

            String description = incomingExtras.getString("description");

            String street = incomingExtras.getString("street");

            String city = incomingExtras.getString("city");

            String state = incomingExtras.getString("state");

            int positionEdited = incomingExtras.getInt("edit");



            if (positionEdited > -1) {

                addressBook.getContactList().remove(positionEdited);

            }



            Contact c = new PersonContact(name, 0L, email, 0, 0, 0, description);

            c.getLocation().setStreet(street);

            c.getLocation().setCity(city);

            c.getLocation().setState(state);

            // The possibility of a null phone variable was crashing my app so I had to handle the NumberFormatException for when the Intent came back null.

            try {

                phone = Long.parseLong(incomingExtras.getString("phone"));

                c.setPhone(phone);

            } catch (NumberFormatException n) {

                c.setPhone(0L);

            }

            addressBook.getContactList().add(c);

            Toast.makeText(this, c.getName() + " has been added.", Toast.LENGTH_LONG).show();







        }



        b_main1.setOnClickListener(v -> {

            Intent i = new Intent(this, AddNewContact.class);

            startActivity(i);

        });

        b_main2.setOnClickListener(v -> {

            Intent i = new Intent(this, ShowAllContacts.class);

            startActivity(i);

        });

        b_main3.setOnClickListener(v -> {

            // Show Contact Actions

            Intent i = new Intent(this, ShowContactActions.class);

            startActivity(i);

        });

        b_main6.setOnClickListener(v -> {

            //         Save All Contacts

            Intent i = new Intent(this, ExitApplication.class);

            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

            startActivity(i);

            finish();

        });







    }

}
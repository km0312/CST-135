package com.example.contactfinal;

import android.content.Intent;

import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;

import android.widget.Button;



public class AddNewContact extends AppCompatActivity {



    Button b_createpersonal, b_createbusiness;



    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_new_contact);



        b_createpersonal = (Button) findViewById(R.id.b_createpersonal);

        b_createbusiness = (Button) findViewById(R.id.b_createbusiness);



        b_createpersonal.setOnClickListener(v -> {

            Intent i = new Intent(v.getContext(), AddPersonContact.class);

            startActivity(i);

            finish();

            return;

        });

    }

}
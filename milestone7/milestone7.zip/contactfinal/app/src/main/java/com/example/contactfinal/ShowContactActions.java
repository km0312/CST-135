package com.example.contactfinal;

import android.content.Intent;

import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;

import android.widget.AdapterView;

import android.widget.ListView;



public class ShowContactActions extends AppCompatActivity {



    ListView lv_actions;

    ActionsAdapter adapter;

    AddressBook addressBook;

    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_show_contact_actions);



        lv_actions = findViewById(R.id.lv_actions);



        addressBook = ((MyApplication) getApplication()).getAddressBook();



        adapter = new ActionsAdapter(ShowContactActions.this, addressBook);

        lv_actions.setAdapter(adapter);



        lv_actions.setOnItemClickListener((parent, view, position, id) -> showPersonActions(position));

    }



    public void showPersonActions(int position) {

        Intent i = new Intent(getApplicationContext(), ContactActions.class);



        // get the contents of contacts at position

        Contact c = addressBook.getContactList().get(position);



        i.putExtra("name", c.getName());

        i.putExtra("phone", Long.toString(c.getPhone()));

        i.putExtra("email", c.getEmail());

        i.putExtra("street", c.getLocation().getStreet());

        i.putExtra("city", c.getLocation().getCity());

        i.putExtra("state", c.getLocation().getState());



        startActivity(i);

    }

}
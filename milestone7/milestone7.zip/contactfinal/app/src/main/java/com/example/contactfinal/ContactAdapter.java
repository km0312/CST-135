package com.example.contactfinal;

import android.Manifest;

import android.app.Activity;

import android.content.Context;

import android.content.Intent;

import android.content.pm.PackageManager;

import android.net.Uri;

import android.support.v4.app.ActivityCompat;

import android.support.v4.content.ContextCompat;

import android.view.LayoutInflater;

import android.view.View;

import android.view.ViewGroup;

import android.widget.BaseAdapter;

import android.widget.Button;

import android.widget.ImageView;

import android.widget.TextView;

import android.widget.Toast;



import org.w3c.dom.Text;



public class ContactAdapter extends BaseAdapter {



    Activity mActivity;

    AddressBook addressBook;



    final static int PERMISSION_TO_CALL = 1;



    public ContactAdapter(Activity mActivity, AddressBook addressBook) {

        this.mActivity = mActivity;

        this.addressBook = addressBook;

    }



    @Override

    public int getCount() {

        return addressBook.getContactList().size();

    }



    @Override

    public Contact getItem(int position) {

        return addressBook.getContactList().get(position);

    }



    @Override

    public long getItemId(int position) {

        return 0;

    }



    @Override

    public View getView(int position, View convertView, ViewGroup parent) {



        View onePersonLine;



        LayoutInflater inflater = (LayoutInflater) mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        onePersonLine = inflater.inflate(R.layout.person_one_line, parent, false);



        TextView tv_onepersonlinename = onePersonLine.findViewById(R.id.tv_onepersonlinename);

        TextView tv_phone_value = onePersonLine.findViewById(R.id.tv_phone_value);

        TextView tv_id = onePersonLine.findViewById(R.id.tv_id);

        ImageView iv_photo = onePersonLine.findViewById(R.id.iv_photo);





        Contact c = this.getItem(position);



        tv_onepersonlinename.setText(c.getName());

        tv_phone_value.setText(Long.toString(c.getPhone()));

        tv_id.setText("ID: " + c.getid());



        int[] pic_resource_numbers = {

                R.drawable.icon_001,

                R.drawable.icon_002,

                R.drawable.icon_003,

                R.drawable.icon_004,

                R.drawable.icon_005,

                R.drawable.icon_006,

                R.drawable.icon_007,

                R.drawable.icon_008,

                R.drawable.icon_009,

        };

        iv_photo.setImageResource(pic_resource_numbers[c.getid() % 8]);





        return onePersonLine;

    }

}
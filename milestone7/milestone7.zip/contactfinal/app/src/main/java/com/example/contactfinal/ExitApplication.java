package com.example.contactfinal;

import android.os.Handler;

import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;





public class ExitApplication extends AppCompatActivity {



    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_exit_application);

        Handler handler = new Handler();

        handler.postDelayed(new Runnable() {

            public void run() {

                // yourMethod();

            }

        }, 5000);   //5 seconds

        ((MyApplication) this.getApplication()).getFile().saveAllContacts(

                ((MyApplication) this.getApplication()).getAddressBook().getContactList()

        );

        finish();

        System.exit(0);

    }

}
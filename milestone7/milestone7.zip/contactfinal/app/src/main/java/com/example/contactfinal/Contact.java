package com.example.contactfinal;

import java.util.ArrayList;



public class Contact implements Comparable<Contact> {

    private int id;

    private String name;

    private long phone;

    private ArrayList<Photo> listOfPhotos = new ArrayList<>();

    private Location location;

    private String email;

    public static int count;

    /**

     * Contact no-arg constructor

     */

    public Contact() {

        this("empty contact", 0, new Location(), new Photo(), null);

    }

    /**

     * Contact full-arg constructor

     * @param name the name of the contact

     * @param phone the phone number of the contact

     * @param location the Location of the contact

     * @param photo A Photo of the contact

     * @param email the email of the contact

     */

    public Contact(String name, long phone, Location location, Photo photo, String email) {

        this.id = count;

        this.name = name;

        this.phone = phone;

        this.location = location;

        this.listOfPhotos.add(photo);

        this.email = email;

        count++;

    }



    /**

     * Get the ID of the contact

     * @return the ID of the contact

     */

    public int getid() {

        return id;

    }



    public void setid(int id) {

        this.id = id;

    }



    /**

     * Get the name of the contact

     * @return the name of the contact

     */

    public String getName() {

        return name;

    }

    /**

     * Set the name of the contact

     * @param name the name of the contact

     */

    public void setName(String name) {

        this.name = name;

    }

    /**

     * Get the phone number of the contact

     * @return the phone number of the contact

     */

    public long getPhone() {

        return phone;

    }

    /**

     * Set the phone number of the contact

     * @param phone the phone number of the contact

     */

    public void setPhone(long phone) {

        this.phone = phone;

    }

    /**

     * Get the list of photos for Contact

     * @return the list of photos for Contact

     */

    public ArrayList<Photo> getListOfPhotos() {

        return listOfPhotos;

    }

    /**

     * Add a photo for the contact

     * @param photo a photo of the contact

     */

    public void addPhoto(Photo photo) {

        this.listOfPhotos.add(photo);

    }

    /**

     * Remove photo of contact

     * @param photo a photo of the contact

     */

    public void removePhoto(Photo photo) {

        this.listOfPhotos.remove(photo);

    }

    /**

     * Get the location of the contact

     * @return the location of the contact as Location object

     */

    public Location getLocation() {

        return location;

    }

    /**

     * Set the location of the contact

     * @param location the location of the contact as Location object

     */

    public void setLocation(Location location) {

        this.location = location;

    }

    /**

     * Get the email of the contact

     * @return the email of the contact as String

     */

    public String getEmail() {

        return email;

    }

    /**

     * Set the email of the contact

     * @param email

     */

    public void setEmail(String email) {

        this.email = email;

    }



    public Photo getPhotoByID(int id) {

        for (Photo p: this.listOfPhotos) {

            if (p.getId() == id)

                return p;

        }

        return null;

    }



    @Override

    public int compareTo(Contact o) {

        int value = this.name.compareTo(o.name);

        if (value == 0) {

            return this.name.compareTo(o.name);

        } else {

            return value;

        }

    }

    @Override

    public String toString() {

        return "Contact [id=" + id + ", name=" + name + ", phone=" + phone + ", listOfPhotos=" + listOfPhotos

                + ", location=" + location + ", email=" + email + "]";

    }









}
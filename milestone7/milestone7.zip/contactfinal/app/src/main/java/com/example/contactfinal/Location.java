package com.example.contactfinal;



public class Location {

    private int id;

    private String street;

    private String city;

    private String state;

    private static int count;



    /**

     * No-arg constructor for Location

     */

    public Location() {

        this(null, null, null);

    }



    /**

     * Non-default constructor for Location object

     *

     * @param street the street of the contact

     * @param city   the city of the contact

     * @param state  the state of the contact

     */

    public Location(String street, String city, String state) {

        this.id = count;

        this.street = street;

        this.city = city;

        this.state = state;

        count++;

    }



    /**

     * Get the ID for the location

     *

     * @return the ID for the location

     */

    public int getId() {

        return id;

    }



    /**

     * Set the ID for the contact

     *

     * @param id the ID for the contact

     */

    public void setId(int id) {

        this.id = id;

    }



    /**

     * Get the street address for the Location object

     *

     * @return the street address for the object

     */

    public String getStreet() {

        return street;

    }



    /**

     * Set the street address for the Location object

     *

     * @param street the street address for the object

     */

    public void setStreet(String street) {

        this.street = street;

    }



    /**

     * Get the city of the Location object

     *

     * @return the city of the object

     */

    public String getCity() {

        return city;

    }



    /**

     * Set the city of the Location object

     *

     * @param city the city of the object

     */

    public void setCity(String city) {

        this.city = city;

    }

    /**

     * Get the State of the Location object

     * @return the State of the object

     */

    public String getState() {

        return state;

    }

    /**

     * Set the State of the Location Object

     * @param state the State of the object

     */

    public void setState(String state) {

        this.state = state;

    }



    // must override equals

    @Override

    public String toString() {

        return "Location [id=" + id + ", street=" + street + ", city=" + city + ", state=" + state + "]";

    }



}
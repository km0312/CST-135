package com.example.contactfinal;

import java.time.LocalTime;

import java.util.Arrays;



public class BusinessContact extends Contact {

    private LocalTime[] hours;

    private String websiteUrl;

    /**

     * No-arg constructor

     */

    public BusinessContact() {

        this(null, 0L, null);

    }

    /**

     * Non-default constructor accepting website as single argument

     * @param websiteUrl the website of the business

     */

    public BusinessContact(String name, Long phone, String websiteUrl) {

        super(name, phone, new Location(), new Photo(), null);

        this.websiteUrl = websiteUrl;

    }

    /**

     * Get the opening and closing hours of the business

     * @return the open and close hours of the business

     */

    public LocalTime[] getHours() {

        return hours;

    }

    /**

     * Set the open and close hours of the business

     * @param openHour the opening hour of the business

     * @param openMinute the opening minute of the business

     * @param closeHour the closing hour of the business

     * @param closeMinute the closing minute of the business

     */

    public void setHours(int openHour, int openMinute, int closeHour, int closeMinute) {

        this.hours[0] = LocalTime.of(openHour, openMinute);

        this.hours[1] = LocalTime.of(closeHour, closeMinute);

    }

    /**

     * Get the website URL

     * @return the URL of the website

     */

    public String getWebsiteUrl() {

        return websiteUrl;

    }

    /**

     * Set the website URL

     * @param websiteUrl the URL of the business website

     */

    public void setWebsiteUrl(String websiteUrl) {

        this.websiteUrl = websiteUrl;

    }



    @Override

    public String toString() {

        return super.toString() + " as BusinessContact [hours=" + Arrays.toString(hours) + ", websiteUrl=" + websiteUrl + "]";

    }



}
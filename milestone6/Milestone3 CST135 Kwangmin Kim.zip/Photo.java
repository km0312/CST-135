package contactapp;

/**
 * Photo class used by Contact Class
 * @author Kwangmin Kim
 */

public class Photo {

	private int id;

	private String fileName;

	private java.util.Date date;

	private String description;

	private static int count;


	public Photo() {

		this(null, "A generic personal photo");

	}

	/**
	 * Photo non-default constructor
	 */

	public Photo(String fileName, String description) {

		this.id = count;

		this.fileName = fileName;

		this.description = description;

		date = new java.util.Date();

		count++;

	}

	/**
	 * Get the ID of the photo
	 */

	public int getId() {

		return id;

	}

	/**
	 * Set the ID of the Photo
	 */

	public void setId(int id) {

		this.id = id;

	}

	/**
	 * Get the File Name of the Photo
	 */

	public String getFileName() {

		return fileName;

	}

	/**
	 * Set the File Name of the Photo
	 */

	public void setFileName(String fileName) {

		this.fileName = fileName;

	}

	/**
	 * Get the date the photo was added
	 */

	public java.util.Date getDate() {

		return date;

	}

	/**
	 * Set the date of the photo
	 */

	public void setDate(java.util.Date date) {

		this.date = date;

	}

	/**
	 * Get the description of the photo
	 */

	public String getDescription() {

		return description;

	}

	/** 
	 * Set the description of the photo
	 */

	public void setDescription(String description) {

		this.description = description;

	}

	



	@Override

	public String toString() {

		return "Photo [id=" + id + ", fileName=" + fileName + ", date=" + date + ", description=" + description + "]";

	}



}

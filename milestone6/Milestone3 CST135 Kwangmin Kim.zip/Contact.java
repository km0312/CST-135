package contactapp;

import java.util.ArrayList;

/**
 * The Contact base class from which PersonContact and BusinessContact inherit
 * @author Kwangmin Kim
 */

public class Contact implements Comparable<Contact> {

	private int id;

	private String name;

	private long phone;

	private ArrayList<Photo> listOfPhotos = new ArrayList<>();

	private Location location;

	private String hobby;

	public static int count;

	public Contact() {

		this("empty contact", 0, new Location(), new Photo(), null);

	}

	
	public Contact(String name, long phone, Location location, Photo photo, String hobby) {

		this.id = count;

		this.name = name;

		this.phone = phone;

		this.location = location;

		this.listOfPhotos.add(photo);

		this.hobby = hobby;

		count++;

	}

	

	/**
	 * Get the ID of the contact
	 */

	public int getid() {

		return id;

	}

	

	public void setid(int id) {

		this.id = id;

	}

	

	/**
	 * Get the name of the contact
	 */

	public String getName() {

		return name;

	}

	/**
	 * Set the name of the contact
	 */

	public void setName(String name) {

		this.name = name;

	}

	/**
	 * Get the phone number of the contact
	 */

	public long getPhone() {

		return phone;

	}

	/**
	 * Set the phone number of the contact
	 */

	public void setPhone(long phone) {

		this.phone = phone;

	}

	/**
	 * Get the list of photos for Contact
	 */

	public ArrayList<Photo> getListOfPhotos() {

		return listOfPhotos;

	}

	/**
	 * Add a photo for the contact
	 */

	public void addPhoto(Photo photo) {

		this.listOfPhotos.add(photo);

	}

	/**
	 * Remove photo of contact
	 */

	public void removePhoto(Photo photo) {

		this.listOfPhotos.remove(photo);

	}

	/**
	 * Get the location of the contact
	 */

	public Location getLocation() {

		return location;

	}

	/**
	 * Set the location of the contact
	 */

	public void setLocation(Location location) {

		this.location = location;

	}

	/**
	 * Get the hobby of the contact
	 */

	public String getHobby() {

		return hobby;

	}

	/**
	 * Set the hobby of the contact
	 */

	public void setHobby(String hobby) {

		this.hobby = hobby;

	}

	

	public Photo getPhotoByID(int id) {

		for (Photo p: this.listOfPhotos) {

			if (p.getId() == id)

				return p;

		}

		return null;	

	}



	@Override

	public int compareTo(Contact o) {

		int value = this.name.compareTo(o.name);

		if (value == 0) {

			return this.name.compareTo(o.name);

		} else {

			return value;

		}

	}

	@Override

	public String toString() {

		return "Contact [id=" + id + ", name=" + name + ", phone=" + phone + ", listOfPhotos=" + listOfPhotos

				+ ", location=" + location + ", hobby=" + hobby + "]";

	}









}
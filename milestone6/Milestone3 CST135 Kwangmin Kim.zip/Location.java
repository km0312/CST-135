package contactapp;

/**
 * The Location class for use by Contact Class
 * 
 * @author Kwangmin Kim
 */

public class Location {

	private int id;

	private String street;

	private String city;

	private String state;

	private static int count;





	public Location() {

		this(null, null, null);

	}



	/**
	 * Non-default constructor for Location object
	 */

	public Location(String street, String city, String state) {

		this.id = count;

		this.street = street;

		this.city = city;

		this.state = state;

		count++;

	}



	/**
	 * Get the ID for the location
	 */

	public int getId() {

		return id;

	}



	/**
	 * Set the ID for the contact
	 */

	public void setId(int id) {

		this.id = id;

	}



	/**
	 * Get the street address for the Location object
	 */

	public String getStreet() {

		return street;

	}



	/**
	 * Set the street address for the Location object
	 */

	public void setStreet(String street) {

		this.street = street;

	}



	/**
	 * Get the city of the Location object
	 */

	public String getCity() {

		return city;

	}



	/**
	 * Set the city of the Location object
	 */

	public void setCity(String city) {

		this.city = city;

	}

	/**
	 * Get the State of the Location object
	 */

	public String getState() {

		return state;

	}

	/**
	 * Set the State of the Location Object
	 */

	public void setState(String state) {

		this.state = state;

	}



	// must override equals

	@Override

	public String toString() {

		return "Location [id=" + id + ", street=" + street + ", city=" + city + ", state=" + state + "]";

	}



}
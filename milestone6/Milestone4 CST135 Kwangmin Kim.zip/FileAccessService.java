package contactapp;

import java.io.File;

import java.io.FileNotFoundException;

import java.io.FileWriter;

import java.io.IOException;

import java.io.PrintWriter;

import java.util.ArrayList;

import java.util.Date;

import java.util.Scanner;

/**
 * The FileAccessService class for reading contacts from a file and providing them to AddressBook as a list
 * @author Kwangmin Kim
 */

public class FileAccessService implements DataAccessService {

	private String targetFile;

	private ArrayList<Contact> tempList = new ArrayList<>();

	
	public FileAccessService() {

		this(null);

	}

	/**
	 * Non-default constructor accepts target file location as argument
	 */

	public FileAccessService(String targetFile) {

		this.targetFile = targetFile;

	}

	/**
	 * Get the location of the target file to be read for contact information
	 */

	public String getTargetFile() {

		return targetFile;

	}

	/**
	 * Set the location (path) of the target file
	 */

	public void setTargetFile(String targetFile) {

		this.targetFile = targetFile;

	}

	// Javadoc comments for this method in DataAccessService interface

	// returns temporary arrayList until DataAccessService and reading from file are

	// fully implemented in subsequent Milestone

	@Override

	public ArrayList<Contact> readAllContacts() {

		

		// Create file object from targetFile data field

		File file = new File(targetFile);

		try {

			// Scanner object to read data from csv

			Scanner sc = new Scanner(file);

			while (sc.hasNextLine()) {

				// capture an entire line from the text file as a string

				String line = sc.nextLine();

				// split the file into tokens representing each variable delimited by ","

				String[] tokens = line.split(",");

				

				Contact c;

				// Create a contact object and pass ref variable with tokens to initializeContact().

				// Then, add to tempList ArrayList

				if (tokens[0].equalsIgnoreCase("b")) {

					c = new BusinessContact();

					tempList.add(initializeContact(c, tokens));

				} else if (tokens[0].equalsIgnoreCase("p")) {

					c = new PersonContact();

					tempList.add(initializeContact(c, tokens));

				} else {

					System.out.println("Invalid Contact Type in Data Source.");

				}

				



			}

			

		} catch (FileNotFoundException e) {

			// TODO Auto-generated catch block

			System.out.println("File not found.");

			e.printStackTrace();

		}

		// Set the Contact count to the size of the list so that new contacts have correct ID sequence

		Contact.count = tempList.size();

		return tempList;

	}

	// Javadoc comments for this method in DataAccessService interface

	@Override

	public void saveAllContacts(ArrayList<Contact> list) {

		File file = new File(targetFile);

		

		try {

			FileWriter fw = new FileWriter(file);

			PrintWriter pw = new PrintWriter(fw);

			

			// For each Contact in list, print properties separated by comma (,)

			for (Contact c: list) {

				if (c instanceof BusinessContact) {

					pw.print("b,"); // col 1

				} else if (c instanceof PersonContact) {

					pw.print("p,");// col 1

				}

				pw.print(c.getid() + ","); // col2

				pw.print(c.getName() + ","); // col3

				pw.print(c.getPhone() + ",");// col4

				pw.print(c.getLocation().getStreet() + ","); //col5

				pw.print(c.getLocation().getCity() + ","); //col6

				pw.print(c.getLocation().getState() + ","); //col7

				pw.print(c.getHobby() + ","); // col8

				// print photo properties delimited by | symbol

				for (int i = 0; i < c.getListOfPhotos().size(); i++) {

					pw.print(c.getListOfPhotos().get(i).getId() + "|");

					pw.print(c.getListOfPhotos().get(i).getFileName() + "|");

					pw.print(c.getListOfPhotos().get(i).getDate().getTime() + "|");

					pw.print(c.getListOfPhotos().get(i).getDescription());

					if (i == c.getListOfPhotos().size() - 1) {

						pw.print(",");

					} else {

						pw.print("|");

					}

				}

				// Determine subtype of c, print only relevant properties

				if (c instanceof BusinessContact) {

					pw.print(((BusinessContact)c).getWebsiteUrl() + ",");

					if (((BusinessContact) c).getHours() != null)

						pw.print(((BusinessContact)c).getHours().toString() + "\n");

				} else if (c instanceof PersonContact) {

					pw.print(((PersonContact)c).getDateOfBirth().getTime() + ",");

					pw.print(((PersonContact)c).getDescription() + ",");

					for (Contact d: ((PersonContact) c).getListOfRelatives()) {

						pw.print(d.getid() + ",");

					}

				}

				// break line after each contact's properties are printed to data source

				pw.print("\n");

			}

			pw.close();

			

		} catch (IOException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

		

		

	}

	

	public Contact initializeContact(Contact c, String[] tokens) {

		// save tokens in corresponding variables

		int id = Integer.valueOf(tokens[1]);

		String name = tokens[2];

		Long phone = Long.valueOf(tokens[3]);

		String address = tokens[4];

		String city = tokens[5];

		String state = tokens[6];

		String hobby = tokens[7];

		// set data fields with token variables

		c.setid(id);

		c.setName(name);

		c.setPhone(phone);

		c.getLocation().setStreet(address);

		c.getLocation().setCity(city);

		c.getLocation().setState(state);

		c.setHobby(hobby);

		

		// Initialize Photo data fields (all contained in token 8 delimited by "|" pipe symbol).

		String[] photoData = tokens[8].split("\\|");

		// Divide tokens in photoData by 4 to determine number of Photo objects.

		for (int i = 0; i < (photoData.length / 4); i++) {

			// for each 4 token set, assign each to corresponding data field

			for (int x = 0; x < photoData.length; x+=4) {

				c.getListOfPhotos().get(i).setId(Integer.valueOf(photoData[x]));

				c.getListOfPhotos().get(i).setFileName(photoData[x + 1]); 

				c.getListOfPhotos().get(i).setDate(new Date(Long.valueOf(photoData[x + 2]))); 

				c.getListOfPhotos().get(i).setDescription(photoData[x + 3]); 

			}

		}

		// set data fields relevant to each subtype of Contact

		if (c instanceof PersonContact) {

			Date dob = new Date(Long.valueOf(tokens[9]));

			String description = tokens[10];

			((PersonContact)c).setDateOfBirth(dob.getYear(), dob.getMonth(), dob.getDay());

			((PersonContact)c).setDescription(description);

		} else if (c instanceof BusinessContact) {

			String website = tokens[9];

			((BusinessContact)c).setWebsiteUrl(website);

		}

		

		return c;

	}



}
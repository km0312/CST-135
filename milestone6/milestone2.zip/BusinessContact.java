package contactapp;

import java.time.LocalTime;

import java.util.Arrays;

/**
 * Business Contact class
 * @author Kwangmin Kim
 */

public class BusinessContact extends Contact {

	private LocalTime[] hours;

	private String websiteUrl;

	/**
	 * No-arg constructor
	 */

	public BusinessContact() {

		this(null, 0L, null);

	}

	/**
	 * Non-default constructor accepting website as single argument
	 */

	public BusinessContact(String name, Long phone, String websiteUrl) {

		super(name, phone, new Location(), new Photo(), null);

		this.websiteUrl = websiteUrl;

	}

	/**
	 * Get the opening and closing hours of the business
	 */

	public LocalTime[] getHours() {

		return hours;

	}

	/**
	 * Set the open and close hours of the business
	 */

	public void setHours(int openHour, int openMinute, int closeHour, int closeMinute) {

		this.hours[0] = LocalTime.of(openHour, openMinute);

		this.hours[1] = LocalTime.of(closeHour, closeMinute);

	}

	/**
	 * Get the website URL
	 */

	public String getWebsiteUrl() {

		return websiteUrl;

	}

	/**
	 * Set the website URL
	 */

	public void setWebsiteUrl(String websiteUrl) {

		this.websiteUrl = websiteUrl;

	}



	@Override

	public String toString() {

		return super.toString() + " as BusinessContact [hours=" + Arrays.toString(hours) + ", websiteUrl=" + websiteUrl + "]";

	}



}